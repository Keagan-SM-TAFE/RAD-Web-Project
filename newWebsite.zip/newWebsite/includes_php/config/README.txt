Development server is hosted on the local machine- The deployment server contains 
configuration files connecting too Acme entertainments servers.
The default configuration configDeveloper until an agreement is reached. 